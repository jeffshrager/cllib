#define MACINTOSH
#ifdef powerc
#  include <MacHeadersPPC>
#else
#  include <MacHeaders68K>
#endif
#include <Sound.h>
#include <FixMath.h>
